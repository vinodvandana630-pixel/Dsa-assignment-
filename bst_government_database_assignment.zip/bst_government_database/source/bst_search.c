#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_KEYS 100
#define KEY_LEN 50

typedef struct Node {
    char key[KEY_LEN];
    struct Node *left;
    struct Node *right;
} Node;

Node *createNode(const char *key) {
    Node *node = (Node *)malloc(sizeof(Node));
    if (node == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
    strcpy(node->key, key);
    node->left = node->right = NULL;
    return node;
}

Node *insert(Node *root, const char *key) {
    if (root == NULL) return createNode(key);
    int cmp = strcmp(key, root->key);
    if (cmp < 0) root->left = insert(root->left, key);
    else if (cmp > 0) root->right = insert(root->right, key);
    return root; /* duplicate keys are ignored */
}

void inorder(Node *root) {
    if (root == NULL) return;
    inorder(root->left);
    printf("%s ", root->key);
    inorder(root->right);
}

int bstSearch(Node *root, const char *key, int *comparisons) {
    while (root != NULL) {
        (*comparisons)++;
        int cmp = strcmp(key, root->key);
        if (cmp == 0) return 1;
        root = (cmp < 0) ? root->left : root->right;
    }
    return 0;
}

int linearSearch(char keys[][KEY_LEN], int n, const char *target, int *comparisons) {
    for (int i = 0; i < n; i++) {
        (*comparisons)++;
        if (strcmp(keys[i], target) == 0) return 1;
    }
    return 0;
}

int height(Node *root) {
    if (root == NULL) return 0;
    int leftHeight = height(root->left);
    int rightHeight = height(root->right);
    return 1 + (leftHeight > rightHeight ? leftHeight : rightHeight);
}

void freeTree(Node *root) {
    if (root == NULL) return;
    freeTree(root->left);
    freeTree(root->right);
    free(root);
}

int main(void) {
    char keys[][KEY_LEN] = {"A102", "A25", "A7", "B100", "B12", "A120", "B3", "A45"};
    int n = (int)(sizeof(keys) / sizeof(keys[0]));
    Node *root = NULL;

    printf("Government Identification Number BST\n");
    printf("Insertion order: ");
    for (int i = 0; i < n; i++) {
        printf("%s%s", keys[i], i == n - 1 ? "\n" : ", ");
        root = insert(root, keys[i]);
    }

    printf("Inorder traversal (lexicographic order): ");
    inorder(root);
    printf("\nNumber of keys: %d\n", n);
    printf("BST height (levels): %d\n", height(root));

    const char *targets[] = {"A120", "B3", "A25", "C10"};
    int targetCount = (int)(sizeof(targets) / sizeof(targets[0]));
    printf("\nSearch comparison (strcmp calls)\n");
    printf("Target\tBST result\tBST comparisons\tLinear result\tLinear comparisons\n");
    for (int i = 0; i < targetCount; i++) {
        int bstComparisons = 0, linearComparisons = 0;
        int bstFound = bstSearch(root, targets[i], &bstComparisons);
        int linearFound = linearSearch(keys, n, targets[i], &linearComparisons);
        printf("%s\t%s\t\t%d\t\t%s\t\t%d\n",
               targets[i], bstFound ? "Found" : "Not found", bstComparisons,
               linearFound ? "Found" : "Not found", linearComparisons);
    }

    freeTree(root);
    return 0;
}
