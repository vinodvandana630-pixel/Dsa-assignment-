# Complexity Analysis and Conclusion

## A. BST structure and inorder traversal

The IDs are compared as complete strings using C's `strcmp()` function. The insertion order is `A102, A25, A7, B100, B12, A120, B3, A45`.

```text
A102
  \
   A25
  /   \
A120   A7
      /  \
    A45   B100
             \
             B12
                \
                B3
```

The tree has 8 nodes and a height of 6 levels. The inorder traversal is:

`A102 A120 A25 A45 A7 B100 B12 B3`

This order is lexicographic string order. It is not numeric sorting of the digits after the letter; for example, `A120` appears before `A25` under string comparison.

## B. Search comparison results

The C program counts one comparison each time it compares the target ID with a stored ID using `strcmp()`.

| Target | BST result | BST comparisons | Linear result | Linear comparisons |
|---|---|---:|---|---:|
| A120 | Found | 3 | Found | 6 |
| B3 | Found | 6 | Found | 7 |
| A25 | Found | 2 | Found | 2 |
| C10 | Not found | 6 | Not found | 8 |

The BST uses fewer comparisons for A120, B3, and the absent key C10 in this particular run. A25 takes the same number of comparisons in both methods. These are results for this exact tree and input order; they do not guarantee that a BST will always outperform linear search.

## C. Key length and insertion order

- **Key length:** `strcmp()` compares characters until it finds a difference or reaches a string terminator. Longer IDs can require more character inspections per key comparison. The program's comparison counts measure calls to `strcmp()`, not the number of individual characters inspected. If IDs contain numbers that should be ordered numerically, parse and compare the numeric portion or define a consistent structured-key comparison.
- **Insertion order:** A standard BST's shape depends on insertion order. Sorted or nearly sorted keys can create a skewed tree with height close to `n`; search can then take O(n) time. A balanced tree keeps height around O(log n), allowing O(log n) search.
- **Observed tree:** This input produces a tree of height 6 for 8 nodes, so it is not balanced. The chain on the right side makes some searches take several comparisons.

## D. Theoretical complexity

Let `n` be the number of stored IDs and `h` be the BST height.

| Operation/structure | Best case | Average/expected case | Worst case |
|---|---|---|---|
| BST search | O(1), target at root | O(log n) for a reasonably balanced tree / typical random insertion | O(n) for a skewed tree |
| BST insertion | O(1) when inserted at root/empty position | O(log n) in a balanced tree | O(n) in a skewed tree |
| Linear search | O(1), first key matches | O(n) | O(n) |
| BST storage | O(n) | O(n) | O(n) |
| Recursive BST traversal/height calculation | O(n) time | O(n) time | O(n) time; recursion stack O(h) |

For `n = 8`, the observed BST search comparison counts are 2–6 for the selected targets. Linear search needs 2–8 comparisons for the same targets. Small datasets can show little practical difference, and actual results depend on target position and tree shape.

## E. Suitable approach as the database grows

For a small, rarely changing list, linear search is simple and may be adequate. For frequent searches, use a self-balancing BST such as an AVL tree or Red-Black tree to keep search, insertion, and deletion at O(log n) worst-case time. If records are stored on disk or in a database system, a B-tree/B+ tree or an indexed database column is often more appropriate. Define a consistent ID ordering rule and test with realistic data sizes and insertion orders.

## Final conclusion

The BST organises the given IDs and supports inorder traversal and search. In this example, BST search uses fewer key comparisons for three of the four selected search keys, but the resulting height of 6 levels shows that insertion order can make a BST uneven. Linear search has O(n) time, while an ordinary BST has O(log n) search only when its shape remains reasonably balanced and O(n) in the worst case. For a growing government database, a self-balancing tree or a database index is a suitable way to maintain predictable search performance.
