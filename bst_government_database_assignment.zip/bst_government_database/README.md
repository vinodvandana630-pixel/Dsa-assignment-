# Government Identification Database: BST vs Linear Search

## Aim
Implement a Binary Search Tree (BST) for government identification numbers, display inorder traversal, compare BST search with linear search, record trace tables, and analyse time/space complexity.

## Files
- `source/bst_search.c` — C source code.
- `input/input.txt` — input keys and selected search keys.
- `output/program_output.txt` — captured execution output.
- `trace/insertion_trace.csv` — insertion trace with parent and direction.
- `trace/search_trace.csv` — search path and comparison counts.
- `analysis/complexity_analysis.md` — complexity analysis, key-length/insertion-order discussion, comparison table, and conclusion.

## Compile and run
```bash
gcc source/bst_search.c -o bst_search
./bst_search
```

The program uses `strcmp()` to compare complete IDs lexicographically. Thus, for example, `A120` sorts before `A25`; this is string ordering, not numeric ordering of the digits. Search comparisons count each key-to-key `strcmp()` call, not individual character comparisons.
